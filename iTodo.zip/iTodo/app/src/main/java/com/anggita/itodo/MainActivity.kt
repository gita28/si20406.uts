package com.anggita.itodo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.anggita.itodo.adapter.DoneAdapter
import com.anggita.itodo.adapter.TodoAdapter
import com.anggita.itodo.data.model.Todo
import com.anggita.itodo.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity(), View.OnClickListener {

    private lateinit var binding: ActivityMainBinding
    private val listTodo = ArrayList<Todo?>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.rvNeedTodo.setHasFixedSize(true)
//        binding.rvDoneTodo.setHasFixedSize(true)

        binding.btnAdd.setOnClickListener(this)
    }

    private fun showRecyclerList() {
        binding.rvNeedTodo.layoutManager = LinearLayoutManager(this)
        val listTodoNeedAdapter = TodoAdapter(listTodo)
        binding.rvNeedTodo.adapter = listTodoNeedAdapter

//        binding.rvDoneTodo.layoutManager = LinearLayoutManager(this)
//        val listTodoDoneAdapter = DoneAdapter()
//        listTodoDoneAdapter.setData(listTodo)
//        binding.rvDoneTodo.adapter = listTodoDoneAdapter
    }

    override fun onClick(v: View?) {
        if(v?.id == R.id.btn_add) {
            listTodo.add(Todo(
                (0 until 100000).random(),
                binding.edtInput.text.toString(),
                false
            ))
        }
        showRecyclerList()
    }

}