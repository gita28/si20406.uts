package com.anggita.itodo.adapter

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.anggita.itodo.data.model.Todo
import com.anggita.itodo.databinding.ItemTodoBinding

class TodoAdapter (private val listTodo : ArrayList<Todo?>) :
    RecyclerView.Adapter<TodoAdapter.ListViewHolder>() {

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): ListViewHolder {
        val binding =
            ItemTodoBinding.inflate(LayoutInflater.from(viewGroup.context), viewGroup, false)
        return ListViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        listTodo[position]?.let { holder.bind(it) }
    }

    override fun getItemCount(): Int = listTodo.size

    inner class ListViewHolder(private val binding: ItemTodoBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(todo: Todo) {
            with(binding) {
                cbContent.text = todo.todoActivity
                if(todo.todoStatus == true) {
                    cbContent.isChecked = true
                    cbContent.isEnabled = false
                    btnSelesai.visibility = View.GONE
                }
                cbContent.setOnClickListener {
                    if (cbContent.isChecked) {
                        btnSelesai.visibility = View.VISIBLE
                    } else {
                        btnSelesai.visibility = View.GONE
                    }
                    cbContent.isChecked = !cbContent.isChecked
                }

                btnSelesai.setOnClickListener {
                    listTodo[adapterPosition] = Todo(
                        todo.todoID,
                        "${todo.todoActivity} (Is Completed)",
                        true
                    )
                    notifyItemChanged(adapterPosition)
                }

                btnHapus.setOnClickListener {
                    listTodo.removeAt(adapterPosition)
                    notifyItemRemoved(adapterPosition)
                    notifyItemRangeChanged(adapterPosition, itemCount)
                }
            }
        }
    }
}