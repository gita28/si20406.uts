package com.anggita.itodo.data.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Todo (
    val todoID: Int? = 0,
    val todoActivity: String? = "activity",
    var todoStatus: Boolean? = false,
) : Parcelable
