package com.anggita.itodo.adapter

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.anggita.itodo.data.model.Todo
import com.anggita.itodo.databinding.ItemTodoBinding

class DoneAdapter :
    RecyclerView.Adapter<DoneAdapter.ListViewHolder>() {
    private val listTodo = ArrayList<Todo?>()
    fun setData(items: ArrayList<Todo>) {
        listTodo.clear()
        val dones = ArrayList<Todo>()
        items.forEach {
            if (it.todoStatus == true) dones.add(it)
        }
        listTodo.addAll(dones)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): ListViewHolder {
        val binding =
            ItemTodoBinding.inflate(LayoutInflater.from(viewGroup.context), viewGroup, false)
        return ListViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        listTodo[position]?.let { holder.bind(it) }
    }

    override fun getItemCount(): Int = listTodo.size

    inner class ListViewHolder(private val binding: ItemTodoBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(todo: Todo) {
            with(binding) {
                if (todo.todoStatus == true) {
                    cbContent.text = todo.todoActivity
                    cbContent.setOnClickListener {
                        if (cbContent.isChecked) {
                            btnSelesai.visibility = View.VISIBLE
                        } else {
                            btnSelesai.visibility = View.GONE
                        }
                        cbContent.isChecked = !cbContent.isChecked
                    }

                    btnSelesai.setOnClickListener {
                        todo.todoStatus = true
                        notifyDataSetChanged()
                    }

                    btnHapus.setOnClickListener {
//                        listTodo.removeAt(adapterPosition)
                        listTodo.remove(todo)
                        notifyItemRemoved(adapterPosition)
                        notifyItemRangeChanged(adapterPosition, itemCount)
                    }
                }
            }
        }
    }
}